const configGameURL = "game/load.html";


const configHomepageURL = chrome.runtime.getManifest().homepage_url;
const configTitle = chrome.runtime.getManifest().name;
const configVersionName = chrome.runtime.getManifest().version_name;



document.title = configTitle + " " + configVersionName;






    var iframe = document.createElement('iframe');
    iframe.src = configGameURL;
    iframe.class = 'iframe';
    iframe.scrolling = 'no';

    var container = document.getElementById('iframe-container');
    container.appendChild(iframe);




class MyGame {
    constructor() {
      this.configHomepageURL = chrome.runtime.getManifest().homepage_url;
      this.configTitle = chrome.runtime.getManifest().name;
      this.configVersionName = chrome.runtime.getManifest().version_name;
      this.setTitle();
  
    }
  
  
    setTitle() {
  
      document.title = this.configTitle + " " + this.configVersionName;
    }
  }
  const myGame = new MyGame();


// Function to open a URL in fullscreen mode
function openFullscreenURL() {
    window.open('https://retrobowl.click', '_blank', 'fullscreen=yes');
  }
  
  // Function to open the rate link of the extension
  function openExtensionRateLink() {
    const extensionId = chrome.runtime.id;
    const extensionRateLink = `https://chrome.google.com/webstore/detail/${extensionId}/reviews`;
    window.open(extensionRateLink, '_blank');
  }
  
  // Attach click event listeners to the buttons
  document.getElementById('fullscreenButton').addEventListener('click', openFullscreenURL);
  document.getElementById('rateButton').addEventListener('click', openExtensionRateLink);
  // Delay for 3 seconds (3000 milliseconds) and then open "step2.html"
// setTimeout(function() {
//   window.open("step2.html", "_blank");
// }, 1000);
