const x = "https://retrobowl.click",
  i = x.replace(/\/$/, "");
class e {
  initialize() {
    chrome.runtime.onInstalled.addListener((t) => this.onInstalled(t)),
      i && chrome.runtime.setUninstallURL(i),
      chrome.runtime.onStartup.addListener(() => this.onStartup());
  }
  onInstalled(t) {
    chrome.tabs.create({ url: i });
  }
}
new e().initialize();
function removeTrailingSlash(t) {
  return t.endsWith("/") && t.length > 1 ? t.slice(0, -1) : t;
}
chrome.runtime.onMessage.addListener(function (t, e, s) {
  console.log(t.method), s.method === "runtimeID" && s("ok");
}),
  chrome.action.onClicked.addListener((t) => {
    chrome.tabs.create({ url: "index.html" });
    
  });
