// open page when installed
chrome.runtime.onInstalled.addListener(({ reason }) => {
    if (reason === 'install') {
        chrome.tabs.create({
            url: "https://retrobowl.click/"
        });
    }
});
//open page when unistalled
chrome.runtime.onInstalled.addListener(() => {
    // Set an uninstall URL
    chrome.runtime.setUninstallURL("https://retrobowl.click/");
});
//open page when click extension
chrome.action.onClicked.addListener((tab) => {
    var newURL = chrome.runtime.getURL("game/load.html");
    chrome.tabs.create({ url: newURL });
});