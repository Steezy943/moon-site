const express = require('express');
const axios = require('axios');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const USERS_FILE = path.join(__dirname, '..', 'users.json');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json({ limit: '4mb' }));

const getUsers = () => {
    if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, JSON.stringify([]));
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
};
const saveUsers = (users) => fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));

// Wisp Configuration Endpoint
app.get('/api/wisp-config', (req, res) => {
    res.json({
        wispUrl: "wss://fsdoifasfiao.educationlearningcollege.lovestoblog.com/socket/"
    });
});

app.post('/api/signup', (req, res) => {
    const { username, password, email } = req.body;
    const users = getUsers();
    const checkUser = username.trim().toLowerCase();
    if (users.find(u => u.username.toLowerCase() === checkUser)) {
        return res.status(400).json({ error: 'This identity has already been claimed.' });
    }
    if (!password || password.length < 8) {
        return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }
    users.push({ username: username.trim(), password, email: email ? email.trim() : null, bio: '', profilePicture: '', nameFont: 'Manrope', nameGradient: 'none', nameColor: '#c5ef7e', nameGlow: true });
    saveUsers(users);
    res.json({ success: true, message: 'Account synchronized successfully!' });
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const users = getUsers();
    const user = users.find(u => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password);
    if (!user) return res.status(400).json({ error: 'Invalid cosmic credentials.' });
    res.json({ success: true, username: user.username });
});

app.get('/api/profile', (req, res) => {
    const username = String(req.query.username || '').trim();
    const user = getUsers().find(item => item.username.toLowerCase() === username.toLowerCase());
    if (!user) return res.status(404).json({ error: 'Profile not found.' });
    res.json({ username: user.username, email: user.email || '', bio: user.bio || '', profilePicture: user.profilePicture || '', nameFont: user.nameFont || 'Manrope', nameGradient: user.nameGradient || 'none', nameColor: user.nameColor || '#c5ef7e', nameGlow: user.nameGlow !== false });
});

app.patch('/api/profile', (req, res) => {
    const { currentUsername, username, bio, profilePicture, nameFont, nameGradient, nameColor, nameGlow, currentPassword, newPassword } = req.body;
    const users = getUsers();
    const user = users.find(item => item.username.toLowerCase() === String(currentUsername || '').trim().toLowerCase());
    if (!user) return res.status(404).json({ error: 'Profile not found.' });
    const nextUsername = String(username || '').trim();
    if (!nextUsername) return res.status(400).json({ error: 'Username cannot be empty.' });
    if (nextUsername.toLowerCase() !== user.username.toLowerCase() && users.some(item => item !== user && item.username.toLowerCase() === nextUsername.toLowerCase())) return res.status(400).json({ error: 'That username is already taken.' });
    if (newPassword && (!currentPassword || currentPassword !== user.password)) return res.status(400).json({ error: 'Current password is incorrect.' });
    if (newPassword && newPassword.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters.' });
    user.username = nextUsername;
    user.bio = String(bio || '').trim().slice(0, 240);
    user.profilePicture = String(profilePicture || '').trim().slice(0, 4000000);
    user.nameFont = ['Manrope', 'DM Mono', 'Georgia', 'Trebuchet MS'].includes(nameFont) ? nameFont : 'Manrope';
    user.nameGradient = ['none', 'moon', 'sunset', 'ice'].includes(nameGradient) ? nameGradient : 'none';
    user.nameColor = /^#[0-9a-f]{6}$/i.test(String(nameColor || '')) ? nameColor : '#c5ef7e';
    user.nameGlow = nameGlow !== false;
    if (newPassword) user.password = newPassword;
    saveUsers(users);
    res.json({ success: true, username: user.username, bio: user.bio, profilePicture: user.profilePicture, nameFont: user.nameFont, nameGradient: user.nameGradient, nameColor: user.nameColor, nameGlow: user.nameGlow });
});

app.get('/proxy', async (req, res) => {
    let targetUrl = req.query.url;
    if (!targetUrl) return res.status(400).send('No URL target provided.');
    if (!/^https?:\/\//i.test(targetUrl)) targetUrl = 'https://' + targetUrl;
    try {
        const response = await axios.get(targetUrl, {
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
            timeout: 12000
        });
        let contentType = response.headers['content-type'] || '';
        if (contentType.includes('text/html')) {
            let html = response.data;
            const origin = new URL(targetUrl).origin;
            html = html.replace(/(href|src)=["']([^"']+)["']/g, (match, attribute, url) => {
                if (url.startsWith('http') || url.startsWith('//')) return `${attribute}="/proxy?url=${encodeURIComponent(url)}"`;
                if (url.startsWith('/')) return `${attribute}="/proxy?url=${encodeURIComponent(origin + url)}"`;
                return match;
            });
            return res.send(html);
        }
        res.set('content-type', contentType);
        res.send(response.data);
    } catch (error) {
        res.status(500).send(`Moon Proxy Error: ${error.message}`);
    }
});

app.listen(PORT, () => console.log(`Moon active on http://localhost:${PORT}`));